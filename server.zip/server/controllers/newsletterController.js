const {
  findSubscriberByEmail,
  createSubscriber,
  reactivateSubscriber,
} = require("../models/newsletterModel");
const pool = require("../config/database");

const subscribeNewsletter = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email is required",
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(normalizedEmail)) {
      return res.status(400).json({
        success: false,
        message: "Please enter a valid email address",
      });
    }

    const existingSubscriber = await findSubscriberByEmail(normalizedEmail);

    if (existingSubscriber?.status === "active") {
      return res.status(409).json({
        success: false,
        message: "This email is already subscribed",
      });
    }

    if (existingSubscriber?.status === "unsubscribed") {
      await reactivateSubscriber(normalizedEmail);

      return res.status(200).json({
        success: true,
        message: "Newsletter subscription reactivated successfully",
      });
    }

    await createSubscriber(normalizedEmail);

    return res.status(201).json({
      success: true,
      message: "Successfully subscribed to our newsletter",
    });
  } catch (error) {
    console.error("Subscribe newsletter error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
};

const getAllSubscriber = async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM newsletter_subscribers");
  res.json({ success: true, data: rows });
};

module.exports = {
  subscribeNewsletter,
  getAllSubscriber,
};
